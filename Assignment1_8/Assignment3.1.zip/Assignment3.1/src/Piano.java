import javax.sound.midi.Instrument;
import javax.sound.midi.Patch;
import javax.sound.midi.Soundbank;

public class Piano extends Instrument {

	protected Piano(Soundbank soundbank, Patch patch, String name, Class<?> dataClass) {
		super(soundbank, patch, name, dataClass);
		// TODO Auto-generated constructor stub
	}

	@Override
	public Object getData() {
		// TODO Auto-generated method stub
		return null;
	}

}
