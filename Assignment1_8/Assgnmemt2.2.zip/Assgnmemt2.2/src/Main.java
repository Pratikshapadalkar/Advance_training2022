	import java.util.Scanner;
public class Main {
	

		 public static void main(String[] args) {
			 try (Scanner s1 = new Scanner(System.in)) {
				System.out.println("Enter a number 1: ");
				  int a = s1.nextInt();
				  try (Scanner s2 = new Scanner(System.in)) {
					System.out.println("Enter a number 2: ");
					  int b = s2.nextInt();
					   int c;
					   System.out.println("sum of two numbers:");
					   System.out.println(a);
					   System.out.println(b);
					for(int i =0 ;i<=12;i++)
					{
						c= a+b;
						
						System.out.println(c);
						a=b;
						b=c;
					}
				}
			}
		}
	}