
public class BookDetails {


	 String name,price;
	 BookDetails( String t, int p)
	 {
	  
	  name = t;
	
	 }
	}
	class BookInfo1 extends Book
	{
	
	 int stock_position;
	 BookInfo1( String t,  int p)
	 {
	  super( t, p);
	  
	  
	 }
	 void show()
	 {
	  System.out.println("Book Details:");
	  System.out.println("name: " + name);
	  System.out.println("price: " + price);
	
	 }
	}
	class Exp1
	{
	 public static void main(String[] args) 
	 {
	  BookInfo ob1 = new BookInfo("java programming",1500);
	  BookInfo ob2 = new BookInfo("let us c",1500);
	  ob1.show();
	  ob2.show();
	  
	 }
	}



