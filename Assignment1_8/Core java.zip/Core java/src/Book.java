
public class Book {
	
	 String name,price;
	 Book( String t, int p)
	 {
	  
	  name = t;
	
	 }
	}
	class BookInfo extends Book
	{
	
	 int stock_position;
	 BookInfo( String t,  int p)
	 {
	  super( t, p);
	  
	  
	 }
	 void show()
	 {
	  System.out.println("Book Details:");
	  System.out.println("name: " + name);
	  System.out.println("price: " + price);
	
	 }
	}
	class Exp
	{
	 public static void main(String[] args) 
	 {
	  BookInfo ob1 = new BookInfo("java programming",1500);
	  BookInfo ob2 = new BookInfo("let us c",1500);
	  ob1.show();
	  ob2.show();
	  
	 }
	}

