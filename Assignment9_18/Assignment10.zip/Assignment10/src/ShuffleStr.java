	import java.util.Scanner;
public class ShuffleStr {


		  static boolean shuffleCheck(String first, String second, String result) {

		    if(first.length() + second.length() != result.length()) {
		      return false;
		    }
		    int i = 0, j = 0, k = 0;

		    while (k != result.length()) {

		      if (i < first.length() && first.charAt(i) == result.charAt(k))
		        i++;

		      else if (j < second.length() && second.charAt(j) == result.charAt(k))
		        j++;

		      else {
		        return false;
		      }

		      k++;
		    }

		   
		    if(i < first.length() || j < second.length()) {
		      return false;
		    }

		    return true;
		  }

		  public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        System.out.println("Enter first input");
	        String first = sc.nextLine();
	     
	        System.out.println("Enter second input");
	        String second= sc.nextLine();
	        System.out.println("Enter result you want answer");
	        String results=sc.nextLine();
	       
		      if (shuffleCheck(first, second, results) == false) {
		        System.out.println("TRUE:  " + results + " is a valid shuffle of " + first + " and " + second);
		      }
		      else {
		        System.out.println("FALSE:  "+results + " is not a valid shuffle of " + first + " and " + second);
		      }
		  
		  }
	}


